<?php
session_start();
error_reporting(E_ERROR | E_PARSE);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kumra Engineering</title>
    
    <!-- Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,200,300,700,600' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100' rel='stylesheet' type='text/css'>
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
        
        @import "bourbon";

body {
    background: #eee !important;    
}

.wrapper {  
    margin-top: 80px;
  margin-bottom: 80px;
}



  .form-signin-heading,
    .checkbox {
      margin-bottom: 30px;
    }

    .checkbox {
      font-weight: normal;
    }

    .form-control {
      position: relative;
      font-size: 16px;
      height: auto;
      padding: 10px;
        @include box-sizing(border-box);

        &:focus {
          z-index: 2;
        }
    }

    input[type="text"] {
      margin-bottom: -1px;
      border-bottom-left-radius: 0;
      border-bottom-right-radius: 0;
    }

    input[type="password"] {
      margin-bottom: 20px;
      border-top-left-radius: 0;
      border-top-right-radius: 0;
    }
}
<script>
var check = "<?php echo  $_SESSION['id'];?>";
if( check != "NULL" )
{ document.getElementById("modal-launcher").style.visibility = "hidden"; 
   document.getElementById("username").text = check;
}

</script>
    </style>
	
	
	<?php
	if(isset($_POST['sign'])){
    include 'config.php';
    session_start();
    if($_SESSION['id'])
    {
         session_destroy();
         $_SESSION['id']=false;
         $_SESSION['id']=null;
    }
	header("location:index.php");}
?>
  </head>
  <body>
   
    <div class="header-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="user-menu">
                        <ul>
                            <li><a href="myaccount.php"><i class="fa fa-user"></i> My Account</a></li>
                            
                            
                            <li><a href="checkout5.php"><i class="fa fa-user"></i> Checkout</a></li>
                            
                        </ul>
						</div>
                </div>					
                  <div class="col-md-4">
                    <div class="header-right">
					 <div class = "loginnn">
					    <ul class="list-unstyled list-inline">
                            <li><button id='modal-launcher' class="btn btn-primary btn-xs" data-toggle="modal" data-target="#login-modal">Login</button></li>
							<li><label id="username" align="RIGHT" ><?php echo  $_SESSION['id'];?></label></li>
           							<!--<li><button id='modal-launcher' class="btn btn-primary btn-xs" data-toggle="modal"  >Logout</button></li>-->
                        </ul>
						<form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
						
						 <ul class="list-unstyled list-inline">
						 
                            <li><button id='submit' name="sign" class="btn btn-primary btn-xs">SignOut</button></li>
							
           							<!--<li><button id='modal-launcher' class="btn btn-primary btn-xs" data-toggle="modal"  >Logout</button></li>-->
                        </ul>
						</form>
					  </div>	
					</div>
				  </div>

						<!-- code for login modal is here -->               
<div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
    	<div class="modal-content">
      		<div class="modal-header login_modal_header">
        		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        		<h2 align="center" class="modal-title" id="myModalLabel">Login to Your Account</h2>
      		</div>
			
      		<div align ="center" class="modal-body login-modal">
      			<div  align ="center" class="wrapper">
                <form align ="center" class="form-signin" method="POST" action="log.php" >       
                  <h2 align ="center" class="form-signin-heading">Please login</h2>
                  <input  type="text" class="form-control" name="user" placeholder="Email Address" required="" />
                  <input type="password" class="form-control" name="pass" placeholder="Password" required=""/>      
                  <label class="checkbox">
                  <input type="checkbox" value="remember-me" id="rememberMe" name="rememberMe"> Remember me
                  </label>
                  <input class="btn btn-lg btn-primary btn-block" type="submit"  >   
                </form>


              </div>															
        		<div class="clearfix"></div>
        		
        		<div class="form-group modal-register-btn">
        			<button class="btn btn-default"><b><a href="register.php">New User Please Register</a></b></button>
        		</div>
      		</div>
      		<div class="clearfix"></div>
      		<div class="modal-footer login_modal_footer">
      		</div>
    	</div>
  	</div>
</div>


                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End header area -->


    
    
    <div class="site-branding-area">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="logo">
                        <h1><a href="index.php">Kumra<span>Engineering</span></a></h1>
                    </div>
                </div>
                
                <div class="col-sm-6">
                    <div class="shopping-item">
                        <a href="#">Cart - <span class="cart-amunt">₹800</span> <i class="fa fa-shopping-cart"></i> <span class="product-count">5</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End site branding area -->
    
    
    <div class="mainmenu-area">
        <div class="container">
            <div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div> 
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="index.php">Home</a></li>
                        <li><a href="shop.php">Shop page</a></li>
                        <li><a href="#">Category</a></li>
                        <li><a href="#">Track your Order</a></li>
                        <li><a href="contact.php">Contact Us </a></li>
						
                    </ul>
                </div>  
            </div>
        </div>
    </div> <!-- End mainmenu area -->
    <div class="slider-area">
        <div class="zigzag-bottom"></div>
        <div id="slide-list" class="carousel carousel-fade slide" data-ride="carousel">
            
            <div class="slide-bulletz">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <ol class="carousel-indicators slide-indicators">
                                <li data-target="#slide-list" data-slide-to="0" class="active"></li>
                                <li data-target="#slide-list" data-slide-to="1"></li>
                                <li data-target="#slide-list" data-slide-to="2"></li>
                            </ol>                            
                        </div>
                    </div>
                </div>
            </div>

            <div class="carousel-inner" role="listbox">
                <div class="item active">
                    <div class="single-slide">
                        <div class="slide-bg slide-one"></div>
                        <div class="slide-text-wrapper">
                            <div class="slide-text">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-6 col-md-offset-6">
                                            <div class="slide-content">
                                                <h2>The best home appliances!...</h2>
                                                <p>We have the best home appliances with the best after-sales service!</p>
                                                <a href="shop.php" class="readmore">See more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="single-slide">
                        <div class="slide-bg slide-two"></div>
                        <div class="slide-text-wrapper">
                            <div class="slide-text">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-6 col-md-offset-6">
                                            <div class="slide-content">
                                                <h2>..At the best prices!</h2>
                                                <p>All our products are sold at the most optimum prices possible, because we truly care about our customers!</p>
                                                <a href="" class="readmore">Learn more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="single-slide">
                        <div class="slide-bg slide-three"></div>
                        <div class="slide-text-wrapper">
                            <div class="slide-text">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-6 col-md-offset-6">
                                            <div class="slide-content">
                                                <h2>..so What are you waiting for?</h2>
                                                <p>Go ahead and purchase any one (or 12) of our products and you'll never utter the word 'regret' again !</p>
                                                <a href="" class="readmore">Learn more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>        
    </div> <!-- End slider area -->
    
    <div class="promo-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6  wow bounceInLeft" data-wow-delay="0.05s">
                    <div class="single-promo">
                        <i class="fa fa-refresh"></i>
                        <p>30 Days return</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6  wow bounceInUp" data-wow-delay="0.05s">
                    <div class="single-promo">
                        <i class="fa fa-truck"></i>
                        <p>Free shipping</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6  wow bounceInDown" data-wow-delay="0.05s">
                    <div class="single-promo">
                        <i class="fa fa-lock"></i>
                        <p>Secure payments</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6  wow bounceInRight" data-wow-delay="0.05s">
                    <div class="single-promo">
                        <i class="fa fa-gift"></i>
                        <p>New products</p>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End promo area -->
    	
    <div class="maincontent-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="latest-product">
                        <h2 class="section-title">Latest Products</h2>
                        <div class="product-carousel">
                            <div class="single-product">
                                <div class="product-f-image">
                                    <img src="img/product-1.jpg" alt="">
                                    <div class="product-hover">
                                        <a href="#" class="add-to-cart-link"><i class="fa fa-shopping-cart"></i> Add to cart</a>
                                        <a href="product1.php" class="view-details-link"><i class="fa fa-link"></i> See details</a>
                                    </div>
                                </div>
                                
                                <h2><a href="product1.php">Sony Smart TV - 2015</a></h2>
                                
                                <div class="product-carousel-price">
                                    <ins>₹700.00</ins> <del>₹800.00</del>
                                </div> 
                            </div>
                            <div class="single-product">
                                <div class="product-f-image">
                                    <img src="img/product-2.jpg" alt="">
                                    <div class="product-hover">
                                        <a href="#" class="add-to-cart-link"><i class="fa fa-shopping-cart"></i> Add to cart</a>
                                        <a href="product1.php" class="view-details-link" ><i class="fa fa-link"></i> See details</a>
                                    </div>
                                </div>
                                
                                <h2><a href="product1.php">Apple new mac book 2015 March :P</a></h2>
                                <div class="product-carousel-price">
                                    <ins>₹899.00</ins> <del>₹999.00</del>
                                </div> 
                            </div>
                            <div class="single-product">
                                <div class="product-f-image">
                                    <img src="img/product-3.jpg" alt="">
                                    <div class="product-hover">
                                        <a href="#" class="add-to-cart-link"><i class="fa fa-shopping-cart"></i> Add to cart</a>
                                        <a href="product1.php" class="view-details-link"><i class="fa fa-link"></i> See details</a>
                                    </div>
                                </div>
                                
                                <h2><a href="product1.php">Apple new i phone 6</a></h2>

                                <div class="product-carousel-price">
                                    <ins>₹400.00</ins> <del>₹425.00</del>
                                </div>                                 
                            </div>
                            <div class="single-product">
                                <div class="product-f-image">
                                    <img src="img/product-4.jpg" alt="">
                                    <div class="product-hover">
                                        <a href="#" class="add-to-cart-link"><i class="fa fa-shopping-cart"></i> Add to cart</a>
                                        <a href="product1.php" class="view-details-link"><i class="fa fa-link"></i> See details</a>
                                    </div>
                                </div>
                                
                                <h2><a href="product1.php">Sony playstation microsoft</a></h2>

                                <div class="product-carousel-price">
                                    <ins>₹200.00</ins> <del>₹225.00</del>
                                </div>                            
                            </div>
                            <div class="single-product">
                                <div class="product-f-image">
                                    <img src="img/product-5.jpg" alt="">
                                    <div class="product-hover">
                                        <a href="#" class="add-to-cart-link"><i class="fa fa-shopping-cart"></i> Add to cart</a>
                                        <a href="product1.php" class="view-details-link"><i class="fa fa-link"></i> See details</a>
                                    </div>
                                </div>
                                
                                <h2><a href="product1.php">Sony Smart Air Condtion</a></h2>

                                <div class="product-carousel-price">
                                    <ins>₹1200.00</ins> <del>₹1355.00</del>
                                </div>                                 
                            </div>
                            <div class="single-product">
                                <div class="product-f-image">
                                    <img src="img/product-6.jpg" alt="">
                                    <div class="product-hover">
                                        <a href="#" class="add-to-cart-link"><i class="fa fa-shopping-cart"></i> Add to cart</a>
                                        <a href="product1.php" class="view-details-link"><i class="fa fa-link"></i> See details</a>
                                    </div>
                                </div>
                                
                                <h2><a href="product1.php">Samsung gallaxy note 4</a></h2>

                                <div class="product-carousel-price">
                                    <ins>₹400.00</ins>
                                </div>                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End main content area -->
    
    <div class="brands-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="brand-wrapper  wow bounceInLeft" data-wow-delay="0.05s">
                        <h2 class="section-title">Brands</h2>
                        <div class="brand-list">
                            <img src="img/samsung.jpg" alt="">
                            <img src="img/lg.png" alt="">
                            <img src="img/sony.png" alt="">
                            <img src="img/voltas.jpg" alt="">
							<img src="img/samsung.jpg" alt="">
                            <img src="img/lg.png" alt="">
                            <img src="img/sony.png" alt="">
                            <img src="img/voltas.jpg" alt="">                              
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End brands area -->
    
    <div class="brands-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="brand-wrapper  wow bounceInLeft" data-wow-delay="0.05s">
                        <h2 class="section-title">User feedback</h2>
                        <div class="brand-list">
							
							<blockquote cite=""><img src="img/stu1.jpg" alt="">
							
<i><h2>"My new AC was delivered well before expected delivery date!"</h2></i> <sub><h5>- Ankita Mishra</h5></sub></blockquote>
<blockquote cite=""><img src="img/stu8.jpg" alt="">
<i><h2>"I love Kumra Engineering's pre-sales as well as post-sales services!"</h2></i> <sub><h5>- Sumit Mehta</h5></sub></blockquote>
<blockquote cite=""><img src="img/stu2.jpg" alt="">
<i><h2>"Love the collection of the latest washing machines that Kumra Engg. has!"</h2></i> <sub><h5>- Neeti Arora</h5></sub></blockquote>
<blockquote cite=""><img src="img/stu3.jpg" alt="">
<i><h2>"Kumra Engineering has the undisputed most reasonable collection of TVs "</h2></i> <sub><h5>-  Anvita Gurjar</h5></sub></blockquote>
<blockquote cite=""><img src="img/stu4.jpg" alt="">
<i><h2>"Unbelievable how amazing the discounts are on all products by Kumra Engineering"</h2></i> <sub><h5>- Abhishek Chowdhury </h5></sub></blockquote>
<blockquote cite=""><img src="img/stu5.jpg" alt="">
<i><h2>"Best home electronics dealer in South West Delhi!"</h2></i> <sub><h5>- Rahul Shah</h5></sub></blockquote>
<blockquote cite=""><img src="img/stu6.jpg" alt="">
<i><h2>"I love Kumra Engineering's easy purchase procedures!"</h2></i> <sub><h5>- Ashish Rana</h5></sub></blockquote>
                          
							
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- End product widget area -->
    
   <div class="footer-top-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="footer-about-us wow bounceInLeft" data-wow-delay="0.05s">
                        <h2>Kumra<span>Engineering</span></h2>
                        <p>The best Engineering, for the best customers. Welcome to our world!</p>
                        <div class="footer-social">
                            <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-youtube"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-linkedin"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-pinterest"></i></a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6">
                    <div class="footer-menu  wow bounceInUp" data-wow-delay="0.05s">
                        <h2 class="footer-wid-title" >User Navigation </h2>
                        <ul>
                            <li><a href="#">My account</a></li>
                            <li><a href="#">Order history</a></li>
                            
                            <li><a href="#">Vendor contact</a></li>
                            <li><a href="#">Front page</a></li>
                        </ul>                        
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6">
                    <div class="footer-menu wow bounceInRight" data-wow-delay="0.05s">
                        <h2 class="footer-wid-title ">Categories</h2>
                        <ul>
                            <li><a href="#">ACs</a></li>
                            <li><a href="#">Refridgerators</a></li>
                            <li><a href="#">Washing Machines</a></li>
                            <li><a href="#">TVs</a></li>
							<li><a href="#">Microwave Ovens</a></li>
                        </ul>                        
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6">
                    <div class="footer-newsletter wow bounceInLeft" data-wow-delay="0.05s">
                        <h2 class="footer-wid-title">Newsletter</h2>
                        <p>Sign up to our newsletter and get exclusive deals you wont find anywhere else straight to your inbox!</p>
                        <div class="newsletter-form">
                            <form action="#">
                                <input type="email" placeholder="Type your email">
                                <input type="submit" value="Subscribe">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End footer top area -->
    
    <div class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="copyright">
                        <p>&copy; 2016 Kumra Engineering.
                    </div>
                </div>
                
                <div class="col-md-4">
                </div>
            </div>
        </div>
    </div> <!-- End footer bottom area -->
   
    <!-- Latest jQuery form server -->
    <script src="https://code.jquery.com/jquery.min.js"></script>
    
    <!-- Bootstrap JS form CDN -->
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    
    <!-- jQuery sticky menu -->
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    
    <!-- jQuery easing -->
    <script src="js/jquery.easing.1.3.min.js"></script>
    
    <!-- Main Script -->
    <script src="js/main.js"></script>
		<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
		<script src="js/wow.min.js"></script>
		<script>
		 new WOW().init();
		</script>
	
  </body>
</html>