<?php
include "config.php";
error_reporting(E_ERROR | E_PARSE);
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>eElectronics - HTML eCommerce Template</title>
    
    <!-- Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,200,300,700,600' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100' rel='stylesheet' type='text/css'>
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
   
    <div class="header-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="user-menu">
                        <ul>
                            <li><a href="#"><i class="fa fa-user"></i> My Account</a></li>
                            <li><a href="#"><i class="fa fa-heart"></i> Wishlist</a></li>
                            <li><a href="cart.html"><i class="fa fa-user"></i> My Cart</a></li>
                            <li><a href="checkout.html"><i class="fa fa-user"></i> Checkout</a></li>
                            <li><a href="#"><i class="fa fa-user"></i> Login</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="header-right">
                        <ul class="list-unstyled list-inline">
                            <li class="dropdown dropdown-small">
                                <a data-toggle="dropdown" data-hover="dropdown" class="dropdown-toggle" href="#"><span class="key">currency :</span><span class="value">USD </span><b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li><a href="#">USD</a></li>
                                    <li><a href="#">INR</a></li>
                                    <li><a href="#">GBP</a></li>
                                </ul>
                            </li>

                            <li class="dropdown dropdown-small">
                                <a data-toggle="dropdown" data-hover="dropdown" class="dropdown-toggle" href="#"><span class="key">language :</span><span class="value">English </span><b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li><a href="#">English</a></li>
                                    <li><a href="#">French</a></li>
                                    <li><a href="#">German</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End header area -->
    
    <div class="site-branding-area">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="logo">
                        <h1><a href="index.html">e<span>Electronics</span></a></h1>
                    </div>
                </div>
                
                <div class="col-sm-6">
                    <div class="shopping-item">
                        <a href="cart.html">Cart - <span class="cart-amunt">$800</span> <i class="fa fa-shopping-cart"></i> <span class="product-count">5</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End site branding area -->
    
    <div class="mainmenu-area">
        <div class="container">
            <div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div> 
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.html">Home</a></li>
                        <li class="active"><a href="shop.html">Shop page</a></li>
                        <li><a href="single-product.html">Single product</a></li>
                        <li><a href="cart.html">Cart</a></li>
                        <li><a href="checkout.html">Checkout</a></li>
                        <li><a href="#">Category</a></li>
                        <li><a href="#">Others</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </div>  
            </div>
        </div>
    </div> <!-- End mainmenu area -->
    
    <div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2>Shop</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <h1 align="center" style="font-size:50px;">Showing</h1>
	<h2 align="center" style="font-size:20px;">(all products)</h2>
	
    <div class="single-product-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
			 <div class="row">
                <div class="col-md-3">
                    <div class="single-sidebar">
                        <div id="substores" class="substores" visibleSubstores="">
    <div class="loading"></div>
    <div class="head">
        <h2>Browse</h2>
    </div>
    <div class="body">


            <ul class="tree">
                <li class="parent store active first">
                    <a data-layout="" href="/" path="home-kitchen" sid="j9e" type="products" class="parent active">
                        <span class="arrow"> </span> Microve Oven
                    </a>

            <ul class="tree">
                <li class="parent store active ">
                    <a data-layout="" href="/" path="home-kitchen/home-appliances" sid="j9e,abm" type="products" class="parent active">
                        <span class="arrow"> </span> Refrigerator
                    </a>

            <ul class="tree">
                <li class="parent store ">
                    <a data-layout="newLayout" class="parent current active">
 AC
                    </a>
            </li>
            </ul>
            </li>
            </ul>
            </li>
            </ul>
    </div>
	 
                    <div id="fcWrap">
                        <div data-ctrl="FacetsCtrl">
        <div id="browse-filter">
            <div id="facetList" class="facetList">

                <div class="body">












    <div class="oneFacet "  >
        <div class="facetContainer">
            <div class="head line fk-uppercase">
                <div class="facet-title">
                    <h2 class="unit line fk-font-15">
                        Brand
                    </h2>
                    <span class="clear-wrap">
                        <a class="clear lmargin15 fk-font-12">Clear</a>
                    </span>
                    <span class="icon minus"></span>
                </div>
            </div>
            <div class="filterBox">
                <input type="text" placeholder="Search by Brand" />
                <span class="search-icon"></span>
                <div class="overlay dont-show"></div>
            </div>
            <ul id="brand" class="facets scroll "    >
                            <li class="facet " title="Whirlpool">
                                <a href="/home-kitchen/home-appliances/refrigerators/pr?sid=j9e,abm,hzg&p[]=facets.price_range%5B%5D=Rs.+25001+-+Rs.+30000&p[]=facets.brand%5B%5D=Whirlpool" class=" active ">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.brand%5B%5D=Whirlpool"  >
                                    <span class="title fk-inline-block lmargin5" original="Whirlpool">Whirlpool</span>
                                        <span class="count">11</span>
                                </a>
                            </li>
                            <li class="facet " title="LG">
                                <a href="/LG.html" class=" active ">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.brand%5B%5D=LG"  >
                                    <span class="title fk-inline-block lmargin5" original="LG">LG</span>
                                        <span class="count">25</span>
                                </a>
                            </li>
                            <li class="facet " title="Samsung">
                                <a href="/home-kitchen/home-appliances/refrigerators/pr?sid=j9e,abm,hzg&p[]=facets.price_range%5B%5D=Rs.+25001+-+Rs.+30000&p[]=facets.brand%5B%5D=Samsung" class=" active ">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.brand%5B%5D=Samsung"  >
                                    <span class="title fk-inline-block lmargin5" original="Samsung">Samsung</span>
                                        <span class="count">23</span>
                                </a>
                            </li>
                            <li class="facet " title="Haier">
                                <a href="/home-kitchen/home-appliances/refrigerators/pr?sid=j9e,abm,hzg&p[]=facets.price_range%5B%5D=Rs.+25001+-+Rs.+30000&p[]=facets.brand%5B%5D=Haier" class=" active ">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.brand%5B%5D=Haier"  >
                                    <span class="title fk-inline-block lmargin5" original="Haier">Haier</span>
                                        <span class="count">8</span>
                                </a>
                            </li>
                            <li class="facet " title="Godrej">
                                <a href="/home-kitchen/home-appliances/refrigerators/pr?sid=j9e,abm,hzg&p[]=facets.price_range%5B%5D=Rs.+25001+-+Rs.+30000&p[]=facets.brand%5B%5D=Godrej" class=" active ">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.brand%5B%5D=Godrej"  >
                                    <span class="title fk-inline-block lmargin5" original="Godrej">Godrej</span>
                                        <span class="count">5</span>
                                </a>
                            </li>
                            <li class="facet " title="Panasonic">
                                <a href="/home-kitchen/home-appliances/refrigerators/pr?sid=j9e,abm,hzg&p[]=facets.price_range%5B%5D=Rs.+25001+-+Rs.+30000&p[]=facets.brand%5B%5D=Panasonic" class=" active ">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.brand%5B%5D=Panasonic"  >
                                    <span class="title fk-inline-block lmargin5" original="Panasonic">Panasonic</span>
                                        <span class="count">1</span>
                                </a>
                            </li>
            </ul>
            <div class="clearfix"></div>
        </div>
    </div>






       <div class="oneFacet "  >
        <div class="facetContainer">
            <input type="text" class="expandedContent dont-show" />
            <div class="head line fk-uppercase">
                <div class="facet-title">
                    <h2 class="unit line fk-font-15">
                        Price
                    </h2>
                    <span class="clear-wrap">
                        <a class="clear lmargin15 fk-font-12">Clear</a>
                    </span>
                    <span class="icon minus"></span>
                </div>
            </div>
            <div class="filterBox">
                <input type="text" placeholder="Search by Price" />
                <span class="search-icon"></span>
                <div class="overlay dont-show"></div>
            </div>
            <ul id="price_range" class="facets scroll "    noFilter="true">
                            <li class="facet " title="Rs. 10000 and Below">
                                <a href="/home-kitchen/home-appliances/refrigerators/pr?sid=j9e,abm,hzg&p[]=facets.price_range%5B%5D=Rs.+25001+-+Rs.+30000&p[]=facets.price_range%5B%5D=Rs.+10000+and+Below" class=" active ">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.price_range%5B%5D=Rs.+10000+and+Below"  >
                                    <span class="title fk-inline-block lmargin5" original="Rs. 10000 and Below">Rs. 10000 and Below</span>
                                        <span class="count">49</span>
                                </a>
                            </li>
                            <li class="facet " title="Rs. 10001 - Rs. 12000">
                                <a href="/home-kitchen/home-appliances/refrigerators/pr?sid=j9e,abm,hzg&p[]=facets.price_range%5B%5D=Rs.+25001+-+Rs.+30000&p[]=facets.price_range%5B%5D=Rs.+10001+-+Rs.+12000" class=" active ">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.price_range%5B%5D=Rs.+10001+-+Rs.+12000"  >
                                    <span class="title fk-inline-block lmargin5" original="Rs. 10001 - Rs. 12000">Rs. 10001 - Rs. 12000</span>
                                        <span class="count">39</span>
                                </a>
                            </li>
                            <li class="facet " title="Rs. 12001 - Rs. 15000">
                                <a href="/home-kitchen/home-appliances/refrigerators/pr?sid=j9e,abm,hzg&p[]=facets.price_range%5B%5D=Rs.+25001+-+Rs.+30000&p[]=facets.price_range%5B%5D=Rs.+12001+-+Rs.+15000" class=" active ">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.price_range%5B%5D=Rs.+12001+-+Rs.+15000"  >
                                    <span class="title fk-inline-block lmargin5" original="Rs. 12001 - Rs. 15000">Rs. 12001 - Rs. 15000</span>
                                        <span class="count">137</span>
                                </a>
                            </li>
                            <li class="facet " title="Rs. 15001 - Rs. 20000">
                                <a href="/home-kitchen/home-appliances/refrigerators/pr?sid=j9e,abm,hzg&p[]=facets.price_range%5B%5D=Rs.+25001+-+Rs.+30000&p[]=facets.price_range%5B%5D=Rs.+15001+-+Rs.+20000" class=" active ">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.price_range%5B%5D=Rs.+15001+-+Rs.+20000"  >
                                    <span class="title fk-inline-block lmargin5" original="Rs. 15001 - Rs. 20000">Rs. 15001 - Rs. 20000</span>
                                        <span class="count">145</span>
                                </a>
                            </li>
                            <li class="facet " title="Rs. 20001 - Rs. 25000">
                                <a href="/home-kitchen/home-appliances/refrigerators/pr?sid=j9e,abm,hzg&p[]=facets.price_range%5B%5D=Rs.+25001+-+Rs.+30000&p[]=facets.price_range%5B%5D=Rs.+20001+-+Rs.+25000" class=" active ">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.price_range%5B%5D=Rs.+20001+-+Rs.+25000"  >
                                    <span class="title fk-inline-block lmargin5" original="Rs. 20001 - Rs. 25000">Rs. 20001 - Rs. 25000</span>
                                        <span class="count">195</span>
                                </a>
                            </li>
                            <li class="facet " title="Rs. 25001 - Rs. 30000">
                                <a href="/home-kitchen/home-appliances/refrigerators/pr?sid=j9e,abm,hzg" class=" active selected">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.price_range%5B%5D=Rs.+25001+-+Rs.+30000"   checked="checked">
                                    <span class="title fk-inline-block lmargin5" original="Rs. 25001 - Rs. 30000">Rs. 25001 - Rs. 30000</span>
                                        <span class="count">267</span>
                                </a>
                            </li>
                            <li class="facet " title="Rs. 30001 and Above">
                                <a href="/home-kitchen/home-appliances/refrigerators/pr?sid=j9e,abm,hzg&p[]=facets.price_range%5B%5D=Rs.+25001+-+Rs.+30000&p[]=facets.price_range%5B%5D=Rs.+30001+and+Above" class=" active ">
                                    <input autocomplete="off" class="facetoption" type="checkbox" value="facets.price_range%5B%5D=Rs.+30001+and+Above"  >
                                    <span class="title fk-inline-block lmargin5" original="Rs. 30001 and Above">Rs. 30001 and Above</span>
                                        <span class="count">511</span>
                                </a>
                            </li>
            </ul>
            <div class="clearfix"></div>
        </div>
    </div>












    <div class="oneFacet "  style='display:none;'>
        <div class="facetContainer">
            <input type="text" class="expandedContent dont-show" />
            <div class="head line fk-uppercase">
                <div class="facet-title">
                    <h2 class="unit line fk-font-15">
                        Available Location
                    </h2>
                    <span class="clear-wrap">
                        <a class="clear lmargin15 fk-font-12">Clear</a>
                    </span>
                    <span class="icon minus"></span>
                </div>
            </div>
            <div class="filterBox">
                <input type="text" placeholder="Search by Available Location" />
                <span class="search-icon"></span>
                <div class="overlay dont-show"></div>
            </div>
            <ul id="available_location" class="facets scroll "    >
            </ul>
            <div class="clearfix"></div>
        </div>
    </div>




                </div>
            </div>
        </div>
    </div>

                    </div>
                
                </div>
                    </div>
                    
                    
                   
                </div>
<?php
        


$sql = "SELECT * FROM product WHERE product_id > 39 ";
$result=$conn->query($sql);
echo "<center><table>"; // start a table tag in the HTML
echo $i;
if ($result->num_rows > 0)
	{
		$i=1;
    while($row = $result->fetch_assoc()) 
	{    
		echo "<tr><td>".'<img src="data:image/jpeg;base64,'.base64_encode($row['product_image']).'"" height="350" width="350"/>'."</td></tr>";
		echo "<tr colspan='2' ><td><b>".$row['product_name']."</b></td></tr>";
		echo "<tr colspan='2' ><td>PRICE:".$row['product_price']."</td></tr>";
		echo "<tr><td>".'<div><form action="checkout.php" method ="GET"><div class="product-option-shop"> <input name="product_id" type="hidden" value="'.$row['product_id'].'"><input type="submit" id="addbutton" value="ADD TO CART" ></form>&nbsp;&nbsp;<form action="product.php" method ="GET"><input name="product_id" type="hidden" value="'.$row['product_id'].'"><input type="submit" id="addbutton" value="SEE DETAILS" ></form></div>'."</td></tr>";
	}
	}
echo "</table></center>"; //Close the table in HTML
	
mysql_close(); 
?>
						</form>                      
                    </div>
                </div>
             
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    <div class="product-pagination text-center">
                        <nav>
                          <ul class="pagination">
                            <li>
                              <a href="#" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                              </a>
                            </li>
                            <li><a href="shop.php">1</a></li>
                            <li><a href="shop2.php">2</a></li>
                            <li><a href="shop3.php">3</a></li>
                            <li><a href="shop4.php">4</a></li>
                            <li><a href="shop5.php">5</a></li>
                            <li>
                              <a href="#" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                              </a>
                            </li>
                          </ul>
                        </nav>                        
                    </div>
                </div>
            </div>
        </div>
    </div>

 <div class="product-widget-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    
                </div>
                <div class="col-md-4">
                                       </div>
                </div>
                <div class="col-md-4">
                                       
                        </div>
                        <div class="single-wid-product">
                         
                        </div>
                        
                        </div>
                    </div>
    <div class="footer-top-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="footer-about-us">
                        <h2>e<span>Electronics</span></h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis sunt id doloribus vero quam laborum quas alias dolores blanditiis iusto consequatur, modi aliquid eveniet eligendi iure eaque ipsam iste, pariatur omnis sint! Suscipit, debitis, quisquam. Laborum commodi veritatis magni at?</p>
                        <div class="footer-social">
                            <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-youtube"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-linkedin"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-pinterest"></i></a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6">
                    <div class="footer-menu">
                        <h2 class="footer-wid-title">User Navigation </h2>
                        <ul>
                            <li><a href="">My account</a></li>
                            <li><a href="">Order history</a></li>
                            <li><a href="">Wishlist</a></li>
                            <li><a href="">Vendor contact</a></li>
                            <li><a href="">Front page</a></li>
                        </ul>                        
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6">
                    <div class="footer-menu">
                        <h2 class="footer-wid-title">Categories</h2>
                        <ul>
                            <li><a href="">Mobile Phone</a></li>
                            <li><a href="">Home accesseries</a></li>
                            <li><a href="">LED TV</a></li>
                            <li><a href="">Computer</a></li>
                            <li><a href="">Gadets</a></li>
                        </ul>                        
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6">
                    <div class="footer-newsletter">
                        <h2 class="footer-wid-title">Newsletter</h2>
                        <p>Sign up to our newsletter and get exclusive deals you wont find anywhere else straight to your inbox!</p>
                        <div class="newsletter-form">
                            <input type="email" placeholder="Type your email">
                            <input type="submit" value="Subscribe">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="copyright">
                        <p>&copy; 2015 eElectronics. All Rights Reserved. Coded with <i class="fa fa-heart"></i> by <a href="http://wpexpand.com" target="_blank">WP Expand</a></p>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="footer-card-icon">
                        <i class="fa fa-cc-discover"></i>
                        <i class="fa fa-cc-mastercard"></i>
                        <i class="fa fa-cc-paypal"></i>
                        <i class="fa fa-cc-visa"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
    <!-- Latest jQuery form server -->
    <script src="https://code.jquery.com/jquery.min.js"></script>
    
    <!-- Bootstrap JS form CDN -->
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    
    <!-- jQuery sticky menu -->
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    
    <!-- jQuery easing -->
    <script src="js/jquery.easing.1.3.min.js"></script>
    
    <!-- Main Script -->
    <script src="js/main.js"></script>
  </body>
</html>