<?php 
 $mysql_host='localhost';
$mysql_user='root';
$mysql_password='';
$db='eco';
$conn=new mysqli($mysql_host,$mysql_user,$mysql_password,$db);
?>