<?php
include "config.php";
$ms=$_POST['t'];
$n=$_POST['n'];
$e=$_POST['e'];
$s=$_POST['s'];
$sql= "INSERT INTO message VALUES('$n','$e','$s','$ms')";
if (mysqli_query($conn, $sql)) {
	header("Location:index.php");
}
else
{
	header("Location:contact.php");
}
?>