<!DOCTYPE>
<html>
<head>
     <title>Thank You</title>
	 
	 <link rel="stylesheet" href="stylet.css" media="all" />
</head>
<body>

      <div class=main_wrapper>
	  
	      <div class=header_wrapper>
		  
		       
		  		 		  		<div id=home><a href="home.php">HOME</a></div>    
 
		  </div>
		  
		  
		  <div class=menubar>
		 
		  </div>

		  <div class=content_wrapper>
		         
		  
		          <div id="content_area">Thank You</div>
		  
		  </div>
		  
		  <div id="footer"><b>Your Order has been placed!!</b></div>
	  
	  
	  
	  
	  
	  </div>


</body>
</html>