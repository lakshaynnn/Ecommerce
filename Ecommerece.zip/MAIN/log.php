<?php
session_start();
include "config.php";
$name= $_POST['user'];
$pass= $_POST['pass'];
$sql=  "SELECT * FROM customer WHERE email = '$name'   AND  password= '$pass'" ;
$result=$conn->query($sql);
if ($result->num_rows > 0)
{         
        while($row = $result->fetch_assoc())
		{			
		$_SESSION['id']=$row['cname'];
		$_SESSION['cid']=$row['cid'];
		}
		header("Location:index.php");
          exit;
}
{
  
  $_SESSION['id']= "USER";
  		header("Location:index.php");
          exit;
}
 $conn->close();
?>