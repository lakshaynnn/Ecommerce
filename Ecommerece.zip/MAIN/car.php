<?php session_start(); ?>
<div style="height:auto; width:1050px;   margin:auto; border:1px solid #EBEBEB; background-color:#ffffff;  ">

            <div style="height:40px; width:1050px; height:auto; border:0px solid #000000; padding-top:5px; background-color:#F1F0F0; border-radius:5px; color:#1C7582;">

         <font style=" font-size:18px;"> &nbsp; Your Cart Details</font>

            </div>

          

            <table border="0" style="width:1050px; height:30px; background-color:#7CE1D6;">

            <tr height="30">

            <td width="75" align="center"><b>S.No.</b></td>

             <td width="75" align="center"><b>Remove.</b></td>

            <td width="300" align="center"><b>Item</b></td>

            <td width="350" align="center"><b>Item Description</b></td>

            <td width="100" align="center"><b>Quantity</b></td>

            <td width="200" align="center"><b>Price(Rs.)</b></td>

            </tr>

            </table>

            <table border="0">

        

            <tr style=" background-color:#fffff; ">

             <?php 

		     include('config.php');
			 $cid= $_SESSION['c_id'];
            $sql="select * from cart where cid =  $cid ";

			 $result=mysql_query($sql);

			 $i=1;

            $amt=0;		

			while($row=mysql_fetch_array($result))

			{

			$price=$row['price']*$row['quantity'];
			?>

	          

            <td width="75" align="center"><?php echo $i;?></td>

             <td width="75" align="center"><a href="cartdel.php?code2=<?php echo $row['ser_no'];?>" style="text-decoration:none;"><img src="images/icon_cart.png"></a></td>

            <td width="300" align="center"><img src="images/<?php echo $row['image1'];?>" height="80" width="110" style="border:0px solid #000000;" ></td>

            <td width="350" align="center"><?php echo $row['product_name'];?></td>

            <td width="100" align="center"><?php echo $row['quantity'];?></td>

             <td width="200" align="center"><?php echo'Rs.'.$price;?></td>

            

             </tr>

            <?php

			$i=$i+1;

        $amt=$amt+$price;
        $_SESSION['amt']=$amt;

		}

		

		?> 

        <tr style="background-color:#7CE1D6; height:30px; ">

        <td width="100" style="background-color:#FFFFFF;"></td>

       <td width="100" style="background-color:#FFFFFF;"></td>

      <td width="300" style="background-color:#FFFFFF;"></td>

       <td width="350" style="background-color:#FFFFFF;"></td>

       <td  width="100" align="center"><b>Total</b></td>

       <td  width="200" align="center"><?php echo" <font color='#FF0000'> <b>Rs. </b></font>" .$amt;?></td>

            </tr></table>